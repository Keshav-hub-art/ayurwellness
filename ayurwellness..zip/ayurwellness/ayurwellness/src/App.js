import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import UserProfile from './components/UserProfile';
import PrakritiQuiz from './components/PrakritiQuiz';
import DietChart from './components/DietChart';
import Schedule from './components/Schedule';
import FollowUps from './components/FollowUps';
import AdminPanel from './components/AdminPanel';

export default function App(){
  return (
    <div className="app">
      <header>
        <h1>AyurWellness</h1>
        <nav>
          <Link to="/">Profile</Link>
          <Link to="/prakriti">Prakriti Quiz</Link>
          <Link to="/diet">Diet Chart</Link>
          <Link to="/schedule">Daily Schedule</Link>
          <Link to="/followups">Follow-ups</Link>
          <Link to="/admin">Admin</Link>
        </nav>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<UserProfile/>}/>
          <Route path="/prakriti" element={<PrakritiQuiz/>}/>
          <Route path="/diet" element={<DietChart/>}/>
          <Route path="/schedule" element={<Schedule/>}/>
          <Route path="/followups" element={<FollowUps/>}/>
          <Route path="/admin" element={<AdminPanel/>}/>
        </Routes>
      </main>
    </div>
  );
}
