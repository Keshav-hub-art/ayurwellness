import React from 'react';

function Suggestion({type}){
  const map = {
    Vata: ['Warm cooked foods','Ghee and healthy oils','Avoid cold/raw foods'],
    Pitta: ['Cooling foods','Less spicy foods','Avoid excess oil and fried items'],
    Kapha: ['Light and dry foods','Spices to stimulate digestion','Avoid heavy dairy and sweets']
  };
  return (
    <div>
      <h3>Diet Suggestions for {type}</h3>
      <ul>
        {map[type]?.map((m,i)=>(<li key={i}>{m}</li>))}
      </ul>
    </div>
  );
}

export default function DietChart(){
  const prakriti = JSON.parse(localStorage.getItem('ayur_prakriti')||'null');
  return (
    <div className="card">
      <h2>Diet Chart</h2>
      {prakriti ? <Suggestion type={prakriti.type}/> : <p>Please complete the Prakriti Quiz first.</p>}
    </div>
  );
}
