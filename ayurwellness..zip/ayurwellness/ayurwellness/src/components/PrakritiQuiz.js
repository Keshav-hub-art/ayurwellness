import React, { useState } from 'react';


const QUESTIONS = [
  { q: 'Body frame is', a: ['Thin/slender','Medium','Sturdy/heavy'], score:[ [1,0,0],[0,1,0],[0,0,1] ] },
  { q: 'Skin type', a: ['Dry/cool','Warm/sensitive','Oily/cool'], score:[ [1,0,0],[0,1,0],[0,0,1] ] },
  { q: 'Digestion', a: ['Variable','Strong','Slow'], score:[ [1,0,0],[0,1,0],[0,0,1] ] },
];

export default function PrakritiQuiz(){
  const [answers, setAnswers] = useState(Array(QUESTIONS.length).fill(null));
  const [result, setResult] = useState(null);

  function select(i, idx){
    const copy = [...answers];
    copy[i]=idx;
    setAnswers(copy);
  }
  function evaluate(){
    const totals = [0,0,0];
    answers.forEach((ans, i)=>{
      if(ans===null) return;
      const sc = QUESTIONS[i].score[ans];
      totals[0]+=sc[0]; totals[1]+=sc[1]; totals[2]+=sc[2];
    });
    // decide highest
    const labels = ['Vata','Pitta','Kapha'];
    const maxIndex = totals.indexOf(Math.max(...totals));
    setResult({type:labels[maxIndex], scores:totals});
    localStorage.setItem('ayur_prakriti', JSON.stringify({type:labels[maxIndex], scores:totals}));
  }

  return (
    <div className="card">
      <h2>Prakriti (Dosha) Analysis</h2>
      {QUESTIONS.map((item,i)=>(
        <div key={i}>
          <p><strong>{item.q}</strong></p>
          {item.a.map((opt,j)=>(
            <label key={j}>
              <input type="radio" name={'q'+i} checked={answers[i]===j} onChange={()=>select(i,j)}/> {opt}
            </label>
          ))}
        </div>
      ))}
      <button onClick={evaluate}>Get Prakriti</button>

      {result && (
        <div style={{marginTop:12}}>
          <h3>Result: {result.type}</h3>
          <p>Scores: Vata {result.scores[0]} | Pitta {result.scores[1]} | Kapha {result.scores[2]}</p>
        </div>
      )}
    </div>
  );
}
