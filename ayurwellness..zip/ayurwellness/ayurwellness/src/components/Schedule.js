import React, { useState } from 'react';
export default function Schedule(){
  const [schedule, setSchedule] = useState(() => {
    return JSON.parse(localStorage.getItem('ayur_schedule')||'{"wake":"6:00 AM","exercise":"30 mins","meditation":"15 mins","meals":"3 times"}');
  });
  function save(){
    localStorage.setItem('ayur_schedule', JSON.stringify(schedule));
    alert('Schedule saved locally.');
  }
  function onChange(e){
    setSchedule({...schedule, [e.target.name]: e.target.value});
  }
  return (
    <div className="card">
      <h2>Daily Schedule</h2>
      <label>Wake-up<input name="wake" value={schedule.wake} onChange={onChange}/></label>
      <label>Exercise<input name="exercise" value={schedule.exercise} onChange={onChange}/></label>
      <label>Meditation<input name="meditation" value={schedule.meditation} onChange={onChange}/></label>
      <label>Meals<input name="meals" value={schedule.meals} onChange={onChange}/></label>
      <button onClick={save}>Save Schedule</button>
    </div>
  );
}
