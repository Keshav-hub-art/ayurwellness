import React from 'react';


export default function AdminPanel(){
  const profile = JSON.parse(localStorage.getItem('ayur_user_profile')||'null');
  const prakriti = JSON.parse(localStorage.getItem('ayur_prakriti')||'null');
  const followups = JSON.parse(localStorage.getItem('ayur_followups')||'[]');

  return (
    <div className="card">
      <h2>Admin Panel</h2>
      <section>
        <h3>Profiles (local)</h3>
        {profile ? <pre>{JSON.stringify(profile, null, 2)}</pre> : <p>No profiles saved locally.</p>}
      </section>
      <section>
        <h3>Prakriti Results</h3>
        {prakriti ? <pre>{JSON.stringify(prakriti, null, 2)}</pre> : <p>No results yet.</p>}
      </section>
      <section>
        <h3>Follow-ups</h3>
        <pre>{JSON.stringify(followups, null, 2)}</pre>
      </section>
    </div>
  );
}
