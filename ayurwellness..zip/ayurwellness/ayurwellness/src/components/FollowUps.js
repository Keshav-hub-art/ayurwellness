import React, { useState } from 'react';
export default function FollowUps(){
  const [items, setItems] = useState(()=> JSON.parse(localStorage.getItem('ayur_followups')||'[]'));
  const [text, setText] = useState('');
  function add(){
    if(!text) return;
    const n = [...items, {id:Date.now(), text, done:false}];
    setItems(n);
    localStorage.setItem('ayur_followups', JSON.stringify(n));
    setText('');
  }
  function toggle(id){
    const n = items.map(i=> i.id===id? {...i, done:!i.done} : i);
    setItems(n); localStorage.setItem('ayur_followups', JSON.stringify(n));
  }
  return (
    <div className="card">
      <h2>Follow-ups / Reminders</h2>
      <div>
        <input placeholder="Add reminder" value={text} onChange={e=>setText(e.target.value)}/>
        <button onClick={add}>Add</button>
      </div>
      <ul>
        {items.map(it=>(
          <li key={it.id}>
            <label><input type="checkbox" checked={it.done} onChange={()=>toggle(it.id)}/> {it.text}</label>
          </li>
        ))}
      </ul>
    </div>
  );
}
