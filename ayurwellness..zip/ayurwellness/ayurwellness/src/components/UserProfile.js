import React, { useState } from 'react';

export default function UserProfile(){
  const [form, setForm] = useState({
    name:'', age:'', gender:'', height:'', weight:'', healthNotes:''
  });

  function onChange(e){
    setForm({...form, [e.target.name]: e.target.value});
  }

  function save(e){
    e.preventDefault();
    // For starter app we save to localStorage
    localStorage.setItem('ayur_user_profile', JSON.stringify(form));
    alert('Profile saved locally.');
  }

  return (
    <div className="card">
      <h2>User Profile</h2>
      <form onSubmit={save}>
        <label>Name<input name="name" value={form.name} onChange={onChange} required/></label>
        <label>Age<input name="age" value={form.age} onChange={onChange} required/></label>
        <label>Gender<select name="gender" value={form.gender} onChange={onChange}><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select></label>
        <label>Height (cm)<input name="height" value={form.height} onChange={onChange}/></label>
        <label>Weight (kg)<input name="weight" value={form.weight} onChange={onChange}/></label>
        <label>Health Notes<textarea name="healthNotes" value={form.healthNotes} onChange={onChange}></textarea></label>
        <button type="submit">Save Profile</button>
      </form>
    </div>
  );
}
