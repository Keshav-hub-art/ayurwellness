# AyurWellness - Starter React App

This is a minimal starter React application for an Ayurvedic wellness app.
Features included:
- User Profile (local storage)
- Prakriti questionnaire (basic scoring)
- Diet suggestions based on Prakriti
- Daily Schedule (local storage)
- Follow-ups / reminders (local storage)
- Admin Panel (reads local storage)

## How to run

1. Extract the zip.
2. In project folder run:
   - `npm install`
   - `npm start`
3. The app runs on localhost:3000 by default.

This is a starter scaffold. For production you'd add:
- Backend API & database (user accounts, secure storage)
- Authentication (admin/user roles)
- Better Prakriti algorithm and richer questionnaire
- Notifications and reminders (push/email)
- Styling and accessibility improvements

//
# Project title

 Ayurvedic Health & Lifestyle.

# Description

AyurWellness is a web-based Ayurvedic health and lifestyle application built with React.
It helps users analyze their Prakriti (Vata, Pitta, Kapha) and provides personalized recommendations for diet, daily routines, and wellness plans.


